// Arina Sofiah binti Hamede, A24CS0227, 11/1/2025

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

void readFile(double data_F[], int& size);
void computeC(const double data_F[], double data_C[], int size);
double average(const double data_C[], int size);
char grade(double data_C);
void writeFile(const double data_F[], const double data_C[], int size);



int main() {
	
    int max = 100, inp_data, high = 0, medium = 0, low = 0;
    double F[max], C[max], average_C;
    
    readFile(F, inp_data);

    computeC(F, C, inp_data);

    average_C = average(C, inp_data);
    cout << "Average of the temperature in Celcius : " << fixed << setprecision(2) << average_C << endl;

    for (int i = 0; i < inp_data; i++) {
    	
        switch (grade(C[i])) {
        	
            case 'H':
                high++;
                break;
                
            case 'M':
                medium++;
                break;
                
            case 'L':
                low++;
                break;
                
        }
    }
    
    cout << "Number of high temperature : " << high << endl;
    cout << "Number of medium temperature : " << medium << endl;
    cout << "Number of low temperature : " << low << endl;

    writeFile(F, C, inp_data);

    return 0;
}


void readFile(double* data_F, int& size) {
    ifstream input("input_LE4.txt" );
    
    if (!input.is_open()) {	
		
		cout << "While opening a file, an error is encountered" << endl;
		
	}
	
	else {
        int i = 0;
        while (input >> data_F[i]) {
        	
            i++;
        }
        
        size = i;
        input.close();
    } 
}


void computeC(const double* data_F, double* data_C, int size) {
	
    for (int i = 0; i < size; i++) {
    	
        data_C[i] = 5.0 / 9.0 * (data_F[i] - 32);
        
    }
}

double average(const double* data_F, int size) {
    double sum = 0.0;
    
    for (int i = 0; i < size; i++) {
        sum = sum + data_F[i];
    }
    
    return sum / size;
}


char grade(double data_C) {
	
    if (data_C >= 35) {
    	
        return 'H';
        
    }
	else if (data_C >= 20) {
    	
        return 'M';
        
    }
	else {
		
        return 'L';
        
    }
}


void writeFile(const double* data_F, const double* data_C, int size) {
    ofstream output("output_LE4.txt");
    
    if (!output.is_open()) {
    	
    	cout << "While opening a file, an error is encountered"  << endl;
    
    } 
	else {
		
		output << "C(Celcius)   F(Farenheit)   Description" << endl;
        output << "==========   ============   ===========" << endl;
        
        for (int i = 0; i < size; i++) {
        	
            output << fixed << setprecision(2) << data_C[i] << "           " << data_F[i] << "           " << grade(data_C[i]) << endl;
            
        }
        
        output.close();
           
    }
}


