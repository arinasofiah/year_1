#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

// Function declarations
void readFile(const string& filename, double F[], int& dataCount);
void computeC(const double F[], double C[], int dataCount);
double average(const double C[], int dataCount);
char grade(double C);
void writeFile(const double F[], const double C[], int dataCount);

int main() {
    const int MAX_SIZE = 100;
    double F[MAX_SIZE];  // Array to store Fahrenheit values
    double C[MAX_SIZE];  // Array to store Celsius values
    int dataCount = 0;   // To store the number of data points read from file
    
    // Read data from file
    readFile("input_LE4.txt", F, dataCount);
    
    // Compute Celsius values
    computeC(F, C, dataCount);
    
    // Calculate average temperature in Celsius
    double avgTemp = average(C, dataCount);
    
    // Count the number of high, medium, and low temperatures
    int highCount = 0, mediumCount = 0, lowCount = 0;
    for (int i = 0; i < dataCount; i++) {
        char tempGrade = grade(C[i]);
        if (tempGrade == 'H') highCount++;
        else if (tempGrade == 'M') mediumCount++;
        else if (tempGrade == 'L') lowCount++;
    }
    
    // Display summary on screen
    cout << "Average of the temperature in Celsius: " << fixed << setprecision(1) << avgTemp << endl;
    cout << "Number of high temperature: " << highCount << endl;
    cout << "Number of medium temperature: " << mediumCount << endl;
    cout << "Number of low temperature: " << lowCount << endl;
    
    // Write detailed output to file
    writeFile(F, C, dataCount);
    
    return 0;
}

// Function to read Fahrenheit values from a file
void readFile(const string filename, double F[], int& dataCount) {
	
    ifstream inFile(filename);
    if (!inFile) {
        cerr << "Error opening file " << filename << endl;
        exit(1);
    }
    
    // Read Fahrenheit values into the array
    while (inFile >> F[dataCount]) {
        dataCount++;
    }
    
    inFile.close();
}

// Function to compute Celsius values from Fahrenheit values
void computeC(const double F[], double C[], int dataCount) {
    for (int i = 0; i < dataCount; i++) {
        C[i] = 5.0 / 9.0 * (F[i] - 32);  // Convert Fahrenheit to Celsius
    }
}

// Function to compute the average temperature in Celsius
double average(const double C[], int dataCount) {
    double sum = 0.0;
    for (int i = 0; i < dataCount; i++) {
        sum += C[i];
    }
    return sum / dataCount;
}

// Function to determine the grade (H, M, or L) for a given Celsius temperature
char grade(double C) {
    if (C >= 35) return 'H';  // High temperature
    else if (C >= 20) return 'M';  // Medium temperature
    else return 'L';  // Low temperature
}

// Function to write the detailed output to a file
void writeFile(const double F[], const double C[], int dataCount) {
    ofstream outFile("output_LE4.txt");
    if (!outFile) {
        cerr << "Error opening output file." << endl;
        exit(1);
    }
    
    outFile << "C(Celsius) F(Fahrenheit) Description" << endl;
    outFile << "========== ============ ===========" << endl;
    
    // Write the Celsius and Fahrenheit values along with the grade
    for (int i = 0; i < dataCount; i++) {
        outFile << fixed << setprecision(2) << C[i] << " ";
        outFile << fixed
